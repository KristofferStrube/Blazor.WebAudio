export function getAttribute(object, attribute) { return object[attribute]; }

export function self(object) { return object; }
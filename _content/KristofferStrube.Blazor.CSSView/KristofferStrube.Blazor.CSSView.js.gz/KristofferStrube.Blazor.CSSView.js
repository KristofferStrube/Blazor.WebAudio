﻿export function getAttribute(object, attribute) { return object[attribute]; }

export function getValueOf(object) { return object; }

export function setAttribute(object, attribute, value) { object[attribute] = value; }